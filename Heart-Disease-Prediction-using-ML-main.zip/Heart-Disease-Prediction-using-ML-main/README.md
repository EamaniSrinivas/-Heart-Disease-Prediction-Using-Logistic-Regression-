# Heart-Disease-Prediction-using-ML
Heart disease predictor made using python in Google colab. Dataset is taken from kaggle. Uses Logistic Regression Model.
